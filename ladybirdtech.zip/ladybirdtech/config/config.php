<?php
error_reporting(0);
$host = "localhost";
$username = "root";
$pass = "";
$DB_name = "ladybirdweb";
$connection = new mysqli($host,$username,$pass,$DB_name);
if($connection->connect_error){
	die("failed to connect DB".$connection->connect_error);
}else{echo "Database Connect Sugccesfully";}

?>