<?php
include_once "../config/config.php";
$u_name = $_POST["name"]; 
$u_pass = $_POST["pass"];
$u_des = $_POST["des"];

echo $u_name;
die();


$sql = "INSERT INTO user (name, password, designation)
		VALUES ('$u_name', '$u_pass', '$u_des')";



if ($connection->query($sql) === TRUE) {
  echo "User record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $connection->error;
} 
?>