
<div style="
    background: #4CAF50;
    text-align: center;
    width: 300px;
    margin: auto;
    padding: 10px;
     /* or absolute */
    position: fixed;
    top: 50%;
    left: 50%;
  /* bring your own prefixes */
    transform: translate(-50%, -50%);
">
<form action="modules/register.php" method="POST">
<h2> Register Form</h2>
<span style="
    padding: 10px;
    display: block;
"><label>Name : </label>
	<input type="text" class="name" id="name"><br></span>
<span style="
    padding: 10px;
    display: block;
">
<label>Password : </label>
	<input type="text" class="pass" id="pass"><br></span>
<span style="
    padding: 10px;
    display: block;
">	
<label>Designation : </label>
	<input type="text" class="des" id="des"><br></span>
<span style="
    padding: 10px;
    display: block;
">	
<input type="submit"></span>

</form></div>