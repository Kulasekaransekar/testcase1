Welcome test

<a href="login.php">Login</a>
<a href="register.php">Register</a>